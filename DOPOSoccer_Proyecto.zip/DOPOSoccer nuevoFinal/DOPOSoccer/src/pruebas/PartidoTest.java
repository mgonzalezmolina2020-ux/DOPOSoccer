package pruebas;

import dominio.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;

/**
 * Pruebas de unidad para verificar las reglas de negocio, físicas,
 * inteligencia artificial y persistencia de la capa de dominio de DOPOSoccer.
 */
public class PartidoTest {

    @Test
    public void deberiaIniciarPartidoConMarcadorEnCero() {
        Partido p = new Partido("Corea del Sur", "Camerún", 800, 500, "goles", 3);
        p.iniciarPartido();

        assertTrue(p.isEnJuego());
        assertFalse(p.isPartidoFinalizado());
        assertEquals(0, p.getJugador1().getGoles());
        assertEquals(0, p.getJugador2().getGoles());
    }

    @Test
    public void deberiaFinalizarPartidoAlAlcanzarLimiteDeGoles() {
        Partido p = new Partido("Nigeria", "Estados Unidos", 800, 500, "goles", 2);
        p.iniciarPartido();

        p.registrarGol(1);
        assertFalse(p.isPartidoFinalizado());
        assertEquals(1, p.getJugador1().getGoles());

        p.registrarGol(1);
        assertTrue(p.isPartidoFinalizado());
        assertFalse(p.isEnJuego());
    }

    @Test
    public void deberiaMoverseLaMaquinaCuandoEstaActivada() {
        Partido p = new Partido("Colombia", "Brasil", 800, 500, "tiempo", 2);
        p.configurarMaquina(true, "Ofensiva");
        p.iniciarPartido();

        double xInicial = p.getJugador2().getX();
        for (int i = 0; i < 15; i++) {
            p.actualizar();
        }
        assertNotEquals(xInicial, p.getJugador2().getX(), "La IA debería desplazar al jugador 2");
    }

    @Test
    public void deberiaGuardarYCargarPartidoCorrectamente() throws Exception {
        Partido original = new Partido("Corea del Sur", "Nigeria", 800, 500, "goles", 5);
        original.iniciarPartido();
        original.registrarGol(1);
        original.registrarGol(2);
        original.registrarGol(2);

        File archivoTemp = File.createTempFile("test_doposoccer", ".dat");
        archivoTemp.deleteOnExit();

        original.guardar(archivoTemp);
        Partido cargado = Partido.cargar(archivoTemp);

        assertEquals(1, cargado.getJugador1().getGoles());
        assertEquals(2, cargado.getJugador2().getGoles());
        assertEquals("Corea del Sur", cargado.getJugador1().getPais());
    }

    @Test
    public void deberiaLanzarExcepcionAlCargarArchivoInexistente() {
        File inexistente = new File("archivo_que_no_existe_12345.dat");
        assertThrows(DOPOSoccerException.class, () -> Partido.cargar(inexistente));
    }
}