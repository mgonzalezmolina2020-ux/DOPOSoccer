package pruebas;
import dominio.Jugador;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas unitarias para la clase Jugador del simulador DOPOSoccer.
 */
public class JugadorTest {

    private Jugador jugador;

    @BeforeEach
    public void setUp() {
        // Inicializamos un jugador de prueba (País: Colombia, X: 100, Y: 400, speed: 5, jump: 5, kick: 5, survival: 5)
        jugador = new Jugador("Colombia", 100.0, 400.0, 5, 5, 5, 5);
    }

    @Test
    public void testConstructorYValoresIniciales() {
        assertEquals("Colombia", jugador.getPais());
        assertEquals(100.0, jugador.getX());
        assertEquals(400.0, jugador.getY());
        assertEquals(0, jugador.getGoles());
        assertEquals(0.0, jugador.getBarraPoder());
        assertTrue(jugador.getY() >= 0); // Verificamos posición inicial válida
    }

    @Test
    public void testCalcularVidaMaxima() {
        // Fórmula en Jugador: 100 * (1 + 0.10 * (survival - 1))
        // Con survival = 5: 100 * (1 + 0.10 * 4) = 100 * 1.4 = 140.0
        double vidaEsperada = 140.0;
        assertEquals(vidaEsperada, jugador.getVidaMaxima(), 0.001);
    }

    @Test
    public void testObtenerMultiplicadorKick() {
        // Fórmula: 1 + 0.10 * (kick - 1)
        // Con kick = 5: 1 + 0.10 * 4 = 1.4
        double multiplicadorEsperado = 1.4;
        assertEquals(multiplicadorEsperado, jugador.obtenerMultiplicadorKick(), 0.001);
    }

    @Test
    public void testMovimientoIzquierdaYDerecha() {
        double xInicial = jugador.getX();
        
        // Mover a la izquierda (resta 8)
        jugador.moverIzquierda(0);
        assertEquals(xInicial - 8, jugador.getX());

        // Mover a la derecha (suma 8)
        jugador.moverDerecha(800);
        assertEquals(xInicial, jugador.getX());
    }

    @Test
    public void testEfectoPatadaVisual() {
        // Al iniciar, los frames de efecto deben ser 0
        assertEquals(0, jugador.getFramesEfectoPatada());

        // Activar efecto de patada
        jugador.activarPatadaVisual();
        assertEquals(10, jugador.getFramesEfectoPatada());

        // Actualizar efecto (resta 1 frame)
        jugador.actualizarEfectoPatada();
        assertEquals(9, jugador.getFramesEfectoPatada());
    }

    @Test
    public void testBarraPoderYUsarPoder() {
        // Inicialmente la barra está en 0
        assertEquals(0.0, jugador.getBarraPoder());

        // Intentar usar el poder cuando no está lleno (debe retornar false y no vaciar)
        assertFalse(jugador.usarPoder());

        // Forzar la barra de poder a 100 (simulando que se llenó)
        jugador.setBarraPoder(100.0);
        assertEquals(100.0, jugador.getBarraPoder());

        // Usar el poder cuando está al máximo (debe retornar true y reiniciar la barra a 0)
        assertTrue(jugador.usarPoder());
        assertEquals(0.0, jugador.getBarraPoder());
    }
}