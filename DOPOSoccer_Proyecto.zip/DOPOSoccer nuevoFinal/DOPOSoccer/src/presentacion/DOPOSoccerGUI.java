package presentacion;

import dominio.Partido;
import dominio.Balon;
import dominio.Jugador;
import dominio.DOPOSoccerException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.HashSet;
import java.util.Set;

/**
 * Ventana principal de la interfaz gráfica para el simulador DOPOSoccer.
 * Se encarga de gestionar la ventana de juego, el bucle principal de actualización (Timer),
 * los menús de archivo, los eventos de teclado para el movimiento de los jugadores y el panel de renderizado.
 */
public class DOPOSoccerGUI extends JFrame {

    /** Instancia del partido actual que coordina la lógica del juego. */
    private Partido partido;

    /** Temporizador encargado de actualizar la lógica y la interfaz periódicamente (~60 FPS). */
    private Timer gameTimer;

    /** Conjunto de códigos de teclas mantenidas presionadas para movimiento fluido y simultáneo. */
    private final Set<Integer> teclasPresionadas = new HashSet<>();

    /** Últimos parámetros configurados para conservarlos al reiniciar la partida. */
    private String ultimoPais1 = "Corea del Sur";
    private String ultimoPais2 = "Camerún";
    private String ultimoTipoFin = "tiempo";
    private int ultimoLimite = 3;
    private boolean ultimoContraMaquina = false;
    private String ultimoPerfilMaquina = "Ofensiva";

    /** Barra de menús superior de la ventana. */
    private JMenuBar menuBar;

    /** Menú desplegable principal "Archivo". */
    private JMenu menuFile;

    /** Opciones del menú: Nuevo Partido, Abrir, Salvar, Salir y Reiniciar. */
    private JMenuItem itemNew, itemOpen, itemSave, itemExit, itemRestart;

    /** Panel personalizado encargado de dibujar los elementos visuales del juego (cancha, jugadores, balón). */
    private CanvasPanel boardPanel;

    /**
     * Constructor que inicializa la ventana principal de la interfaz, configura
     * sus propiedades visuales, los componentes, los controladores de eventos
     * y arranca el temporizador del juego.
     */
    public DOPOSoccerGUI() {
        setTitle("DOPOSoccer - Jugador vs Jugador / Máquina");

        setSize(800, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);

        prepareView();
        prepareController();

        setVisible(true);

        // Lanza la ventana de selección de país y modalidad al iniciar
        configurarNuevoPartido();

        gameTimer = new Timer(16, e -> {
            if (partido != null) {
                procesarMovimientoContinuo();
                partido.actualizar();
                boardPanel.repaint();
                verificarFinDelPartido();
            }
        });
        gameTimer.start();
    }

    /**
     * Configura y construye los componentes visuales de la interfaz,
     * incluyendo la barra de menú y el panel de dibujo central de la cancha.
     */
    private void prepareView() {
        menuBar = new JMenuBar();
        menuFile = new JMenu("Archivo");

        itemNew = new JMenuItem("Nuevo Partido");
        itemOpen = new JMenuItem("Abrir");
        itemSave = new JMenuItem("Salvar");
        itemRestart = new JMenuItem("Reiniciar");
        itemExit = new JMenuItem("Salir");

        menuFile.add(itemNew);
        menuFile.addSeparator();
        menuFile.add(itemOpen);
        menuFile.add(itemSave);
        menuFile.addSeparator();
        menuFile.add(itemRestart);
        menuFile.addSeparator();
        menuFile.add(itemExit);

        menuBar.add(menuFile);
        setJMenuBar(menuBar);

        boardPanel = new CanvasPanel();
        add(boardPanel, BorderLayout.CENTER);
    }

    /**
     * Configura los oyentes de eventos para los controles de teclado de los jugadores,
     * el redimensionamiento de la pantalla, los clics en el menú y el cierre de la ventana.
     */
    private void prepareController() {
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                exit();
            }
        });

        // Detecta cuando maximizan o cambian el tamaño de la ventana para que los jugadores no floten
        boardPanel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                if (partido != null) {
                    partido.actualizarDimensiones(boardPanel.getWidth(), boardPanel.getHeight());
                }
            }
        });

        itemExit.addActionListener(e -> exit());
        itemOpen.addActionListener(e -> openFile());
        itemSave.addActionListener(e -> saveFile());
        itemRestart.addActionListener(e -> restartGame());
        itemNew.addActionListener(e -> configurarNuevoPartido());

        // Usamos Key Bindings en el panel para que detecte varias teclas a la vez sin perder el foco
        InputMap im = boardPanel.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = boardPanel.getActionMap();

        int[] teclasJuego = {
            KeyEvent.VK_A, KeyEvent.VK_D, KeyEvent.VK_W, KeyEvent.VK_S, KeyEvent.VK_F,
            KeyEvent.VK_LEFT, KeyEvent.VK_RIGHT, KeyEvent.VK_UP, KeyEvent.VK_DOWN, KeyEvent.VK_SHIFT,
            KeyEvent.VK_SPACE
        };

        for (int key : teclasJuego) {
            String pressKey = "press_" + key;
            String releaseKey = "release_" + key;

            im.put(KeyStroke.getKeyStroke(key, 0, false), pressKey);
            im.put(KeyStroke.getKeyStroke(key, 0, true), releaseKey);

            // También registrar cuando Shift está presionado junto a otras teclas
            im.put(KeyStroke.getKeyStroke(key, InputEvent.SHIFT_DOWN_MASK, false), pressKey);
            im.put(KeyStroke.getKeyStroke(key, InputEvent.SHIFT_DOWN_MASK, true), releaseKey);

            am.put(pressKey, new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    boolean eraNueva = teclasPresionadas.add(key);
                    if (eraNueva && partido != null) {
                        ejecutarAccionUnica(key);
                    }
                }
            });

            am.put(releaseKey, new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    teclasPresionadas.remove(key);
                }
            });
        }
    }

    /**
     * Ejecuta las acciones instantáneas que requieren una pulsación individual (patear, usar poder).
     *
     * @param key Código de la tecla presionada.
     */
    private void ejecutarAccionUnica(int key) {
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();
        Balon b = partido.getBalon();

        if (key == KeyEvent.VK_S) partido.patear(j1);
        if (key == KeyEvent.VK_F) j1.usarPoder();

        // Solo permitir controles manuales de J2 si no es controlado por la máquina
        if (!partido.isContraMaquina()) {
            if (key == KeyEvent.VK_DOWN) partido.patear(j2);
            if (key == KeyEvent.VK_SHIFT) j2.usarPoder();
        }

        if (key == KeyEvent.VK_SPACE) {
            b.aplicarImpulso(0, -6);
        }
    }

    /**
     * Procesa en cada fotograma las teclas de desplazamiento y salto mantenidas presionadas
     * para permitir avanzar y saltar simultáneamente y de forma fluida.
     */
    private void procesarMovimientoContinuo() {
        int anchoCancha = boardPanel.getWidth();

        // Jugador 1: avanzar y saltar simultáneamente
        if (teclasPresionadas.contains(KeyEvent.VK_A)) partido.getJugador1().moverIzquierda(0);
        if (teclasPresionadas.contains(KeyEvent.VK_D)) partido.getJugador1().moverDerecha(anchoCancha);
        if (teclasPresionadas.contains(KeyEvent.VK_W)) partido.getJugador1().saltar();

        // Jugador 2: avanzar y saltar simultáneamente (solo si es humano)
        if (!partido.isContraMaquina()) {
            if (teclasPresionadas.contains(KeyEvent.VK_LEFT)) partido.getJugador2().moverIzquierda(0);
            if (teclasPresionadas.contains(KeyEvent.VK_RIGHT)) partido.getJugador2().moverDerecha(anchoCancha);
            if (teclasPresionadas.contains(KeyEvent.VK_UP)) partido.getJugador2().saltar();
        }
    }

    /**
     * Panel interno encargado de renderizar el campo de juego y los gráficos de la simulación.
     */
    private class CanvasPanel extends JPanel {

        /**
         * Constructor del panel que inicializa los colores y propiedades estéticas de la cancha.
         */
        public CanvasPanel() {
            setBackground(new Color(34, 139, 34));
        }

        /**
         * Método encargado de pintar los elementos gráficos en pantalla (cielo, estadio, césped,
         * porterías con red, balón detallado, balones falsos de ilusión, avatares estilizados,
         * HUD de salud/poder y marcador).
         *
         * @param g Gráficos base utilizados para el renderizado.
         */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (partido == null) return;

            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            int width = getWidth();
            int height = getHeight();
            int sueloY = height - 50;

            // 1. Fondo tipo cielo/estadio con degradado suave
            GradientPaint cielo = new GradientPaint(0, 0, new Color(25, 65, 115), 0, sueloY - 120, new Color(75, 145, 200));
            g2d.setPaint(cielo);
            g2d.fillRect(0, 0, width, sueloY - 110);

            // Gradas / muro de fondo del estadio
            g2d.setColor(new Color(35, 55, 45));
            g2d.fillRect(0, sueloY - 130, width, 30);
            g2d.setColor(new Color(220, 220, 220, 90));
            g2d.fillRect(0, sueloY - 132, width, 3);

            // 2. Césped con franjas verticales en dos tonos de verde
            int zonaCespedY = sueloY - 100;
            int anchoFranja = 60;
            for (int x = 0; x < width; x += anchoFranja) {
                if ((x / anchoFranja) % 2 == 0) {
                    g2d.setColor(new Color(46, 155, 52));
                } else {
                    g2d.setColor(new Color(38, 138, 44));
                }
                g2d.fillRect(x, zonaCespedY, anchoFranja, 100);
            }

            // Suelo inferior (borde de tierra/césped oscuro)
            g2d.setColor(new Color(22, 85, 28));
            g2d.fillRect(0, sueloY, width, 50);
            g2d.setColor(new Color(180, 230, 180));
            g2d.fillRect(0, sueloY, width, 3);

            // 3. Líneas de la cancha (línea de fondo, áreas y círculo central)
            g2d.setColor(new Color(255, 255, 255, 190));
            g2d.setStroke(new BasicStroke(3));
            g2d.drawLine(0, zonaCespedY, width, zonaCespedY);
            g2d.drawLine(width / 2, zonaCespedY, width / 2, sueloY);
            g2d.drawOval(width / 2 - 45, zonaCespedY + 20, 90, 60);
            g2d.fillOval(width / 2 - 4, zonaCespedY + 46, 8, 8);
            g2d.drawRect(0, zonaCespedY + 15, 75, 85);
            g2d.drawRect(width - 75, zonaCespedY + 15, 75, 85);

            // 4. Porterías con malla (red) y postes metálicos
            dibujarPorteria(g2d, 0, sueloY - 150, 22, 150, true);
            dibujarPorteria(g2d, width - 22, sueloY - 150, 22, 150, false);

            // 5. Sombra y dibujo del Balón real
            Balon b = partido.getBalon();
            int radio = (int) b.getRadio();
            int bx = (int) b.getX();
            int by = (int) b.getY();
            dibujarBalonVisual(g2d, bx, by, radio, sueloY);

            // 5b. Si está activo el poder Ilusión (Estados Unidos), dibujar los 7 balones falsos idénticos
            double[][] falsos = partido.getBalonesFalsos();
            if (falsos != null) {
                for (double[] posFalso : falsos) {
                    dibujarBalonVisual(g2d, (int) posFalso[0], (int) posFalso[1], radio, sueloY);
                }
            }

            // 6. Dibujar Jugador 1 y Jugador 2 estilizados (tipo Head Soccer)
            Jugador j1 = partido.getJugador1();
            Jugador j2 = partido.getJugador2();
            dibujarJugador(g2d, j1, true);
            dibujarJugador(g2d, j2, false);

            // 7. --- HUD SUPERIOR: MARCADOR Y BARRAS ESTILIZADAS ---
            dibujarHUD(g2d, width, j1, j2);

            // Barra inferior de controles
            g2d.setColor(new Color(235, 245, 235));
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            String textoJ2 = partido.isContraMaquina()
                ? "J2: MÁQUINA (" + partido.getPerfilMaquina() + ")"
                : "J2: Flechas (Mover/Saltar), Abajo (Patear), Shift (Poder)";
            g2d.drawString("J1: A/D (Mover), W (Saltar), S (Patear), F (Poder)  |  " + textoJ2, 25, height - 18);

            // Si el partido finalizó, mostrar aviso central
            if (partido.isPartidoFinalizado()) {
                g2d.setColor(new Color(0, 0, 0, 150));
                g2d.fillRoundRect(width / 2 - 190, height / 2 - 40, 380, 60, 20, 20);
                g2d.setFont(new Font("Arial", Font.BOLD, 28));
                g2d.setColor(Color.YELLOW);
                g2d.drawString("¡PARTIDO FINALIZADO!", width / 2 - 165, height / 2);
            }
        }

        /**
         * Dibuja un balón con su sombra en el suelo. Se reutiliza para el balón real
         * y para los 7 balones falsos del poder Ilusión.
         */
        private void dibujarBalonVisual(Graphics2D g2d, int bx, int by, int radio, int sueloY) {

            g2d.setColor(Color.WHITE);
            g2d.fillOval(bx - radio, by - radio, radio * 2, radio * 2);
            g2d.setColor(new Color(40, 40, 40));
            g2d.fillOval(bx - 4, by - 4, 8, 8);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(bx - radio, by - radio, radio * 2, radio * 2);
        }

        /**
         * Dibuja una portería con red entrecruzada y postes blancos.
         *
         * @param g2d       Contexto gráfico 2D.
         * @param x         Coordenada X de la portería.
         * @param y         Coordenada Y superior de la portería.
         * @param w         Ancho de la portería.
         * @param h         Alto de la portería.
         * @param izquierda True si es la portería izquierda, false si es la derecha.
         */
        private void dibujarPorteria(Graphics2D g2d, int x, int y, int w, int h, boolean izquierda) {
            g2d.setColor(new Color(255, 255, 255, 45));
            g2d.fillRect(x, y, w, h);

            g2d.setColor(new Color(220, 220, 220, 140));
            g2d.setStroke(new BasicStroke(1));
            for (int py = y; py <= y + h; py += 12) {
                g2d.drawLine(x, py, x + w, py);
            }
            for (int px = x; px <= x + w; px += 7) {
                g2d.drawLine(px, y, px, y + h);
            }

            g2d.setColor(Color.WHITE);
            g2d.setStroke(new BasicStroke(4));
            g2d.drawRect(x, y, w, h);
        }

        /**
         * Dibuja el avatar estilizado de un jugador respetando su caja de colisión,
         * con uniforme según su país, cabeza expresiva, guayos, animación de patada,
         * aura de poder activo, efectos recibidos y estado de aturdimiento.
         *
         * @param g2d         Contexto gráfico 2D.
         * @param j           Instancia del jugador a dibujar.
         * @param miraDerecha True si el jugador mira hacia la derecha (J1), false si mira a la izquierda (J2).
         */
        private void dibujarJugador(Graphics2D g2d, Jugador j, boolean miraDerecha) {
            int x = (int) j.getX();
            int y = (int) j.getY();
            int w = (int) j.getAncho();
            int h = (int) j.getAlto();

            Color[] colores = obtenerColoresPais(j.getPais());
            Color colorCamiseta = colores[0];
            Color colorPantalon = colores[1];

            // Aura visible cuando el jugador activa su poder (sin límite de tiempo hasta tocar el balón)
            if (j.isTienePoderActivo()) {
                g2d.setColor(new Color(0, 220, 255, 175));
                g2d.setStroke(new BasicStroke(3.5f));
                g2d.drawOval(x - 8, y - 16, w + 16, h + 20);
            }

            // Sombra debajo del jugador
            g2d.setColor(new Color(0, 0, 0, 70));
            g2d.fillOval(x + 2, y + h - 4, w - 4, 8);

            // Pie de apoyo trasero
            g2d.setColor(new Color(30, 30, 30));
            int pieApoyoX = miraDerecha ? x + 4 : x + w - 18;
            g2d.fillRoundRect(pieApoyoX, y + h - 10, 14, 10, 4, 4);

            // Pie delantero (se levanta y sobresale al patear en ambos jugadores)
            if (j.getFramesEfectoPatada() > 0) {
                int piePatadaX = miraDerecha ? x + w - 2 : x - 14;
                g2d.setColor(new Color(255, 140, 0));
                g2d.fillRoundRect(piePatadaX, y + h - 18, 16, 11, 5, 5);
                g2d.setColor(Color.BLACK);
                g2d.setStroke(new BasicStroke(1.2f));
                g2d.drawRoundRect(piePatadaX, y + h - 18, 16, 11, 5, 5);

                g2d.setColor(new Color(255, 255, 100, 200));
                g2d.setStroke(new BasicStroke(3));
                int ondaX = miraDerecha ? x + w + 4 : x - 24;
                g2d.drawArc(ondaX, y + h - 32, 20, 28, miraDerecha ? -60 : 120, 120);
            } else {
                int pieDelanteroX = miraDerecha ? x + w - 18 : x + 4;
                g2d.setColor(new Color(30, 30, 30));
                g2d.fillRoundRect(pieDelanteroX, y + h - 10, 14, 10, 4, 4);
            }

            // Pantaloneta
            g2d.setColor(colorPantalon);
            g2d.fillRoundRect(x + 5, y + 42, w - 10, 18, 6, 6);

            // Camiseta
            g2d.setColor(colorCamiseta);
            g2d.fillRoundRect(x + 3, y + 20, w - 6, 25, 10, 10);
            g2d.setColor(new Color(0, 0, 0, 80));
            g2d.setStroke(new BasicStroke(1.5f));
            g2d.drawRoundRect(x + 3, y + 20, w - 6, 25, 10, 10);

            // Cabeza
            int headSize = 34;
            int headX = x + (w - headSize) / 2;
            int headY = y - 10;
            g2d.setColor(new Color(245, 200, 160));
            g2d.fillOval(headX, headY, headSize, headSize);
            g2d.setColor(new Color(60, 40, 25));
            g2d.drawOval(headX, headY, headSize, headSize);

            // Cabello superior
            g2d.setColor(new Color(45, 30, 20));
            g2d.fillArc(headX, headY - 2, headSize, 18, 0, 180);

            // Ojo mirando hacia el rival
            int eyeX = miraDerecha ? headX + 20 : headX + 7;
            g2d.setColor(Color.WHITE);
            g2d.fillOval(eyeX, headY + 12, 7, 8);
            g2d.setColor(Color.BLACK);
            g2d.fillOval(miraDerecha ? eyeX + 3 : eyeX + 1, headY + 14, 3, 4);

            // Indicador de efecto recibido activo sobre el rival
            if (j.getTiempoEfectoRestante() > 0.0 && !"Ninguno".equalsIgnoreCase(j.getEfectoRecibido())) {
                g2d.setColor(Color.ORANGE);
                g2d.setFont(new Font("Arial", Font.BOLD, 11));
                g2d.drawString(String.format("%s (%.1fs)", j.getEfectoRecibido().toUpperCase(), j.getTiempoEfectoRestante()), x - 20, y - 33);
            }

            // Indicador de aturdimiento cuando la vida llega a 0
            if (j.isAturdido()) {
                g2d.setColor(Color.YELLOW);
                g2d.setFont(new Font("Arial", Font.BOLD, 12));
                g2d.drawString(String.format("ATURDIDO (%.1fs)", j.getTiempoAturdidoRestante()), x - 18, y - 20);
            }
        }

        /**
         * Retorna los colores de camiseta y pantaloneta según el país seleccionado.
         *
         * @param pais Nombre del país del jugador.
         * @return Arreglo de dos colores: [0] camiseta, [1] pantaloneta.
         */
        private Color[] obtenerColoresPais(String pais) {
            if ("Colombia".equalsIgnoreCase(pais)) return new Color[]{new Color(252, 209, 22), new Color(0, 56, 147)};
            if ("Brasil".equalsIgnoreCase(pais)) return new Color[]{new Color(255, 223, 0), new Color(0, 156, 59)};
            if ("Argentina".equalsIgnoreCase(pais)) return new Color[]{new Color(116, 172, 223), new Color(25, 35, 50)};
            if ("España".equalsIgnoreCase(pais)) return new Color[]{new Color(198, 11, 30), new Color(0, 45, 114)};
            if ("México".equalsIgnoreCase(pais)) return new Color[]{new Color(0, 104, 71), Color.WHITE};
            if ("Corea".equalsIgnoreCase(pais) || "Corea del Sur".equalsIgnoreCase(pais)) return new Color[]{new Color(205, 46, 58), Color.BLACK};
            if ("Camerún".equalsIgnoreCase(pais)) return new Color[]{new Color(0, 122, 94), new Color(206, 17, 38)};
            if ("Nigeria".equalsIgnoreCase(pais)) return new Color[]{new Color(0, 135, 81), Color.WHITE};
            if ("Estados Unidos".equalsIgnoreCase(pais)) return new Color[]{Color.WHITE, new Color(0, 40, 104)};
            return new Color[]{Color.RED, Color.BLUE};
        }

        /**
         * Dibuja el marcador superior estilo broadcast y las barras de vida y poder.
         *
         * @param g2d   Contexto gráfico 2D.
         * @param width Ancho actual del panel.
         * @param j1    Instancia del jugador 1.
         * @param j2    Instancia del jugador 2.
         */
        private void dibujarHUD(Graphics2D g2d, int width, Jugador j1, Jugador j2) {
            g2d.setColor(new Color(15, 25, 35, 175));
            g2d.fillRoundRect(10, 8, width - 20, 48, 14, 14);

            g2d.setColor(new Color(25, 40, 55));
            g2d.fillRoundRect(width / 2 - 95, 10, 190, 44, 12, 12);
            g2d.setColor(Color.YELLOW);
            g2d.setFont(new Font("Arial", Font.BOLD, 18));
            String marcador = j1.getGoles() + "  -  " + j2.getGoles();
            FontMetrics fm = g2d.getFontMetrics();
            g2d.drawString(marcador, width / 2 - fm.stringWidth(marcador) / 2, 30);

            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 11));
            String tiempoTxt = partido.getTiempoRestanteFormateado();
            FontMetrics fmTiempo = g2d.getFontMetrics();
            g2d.drawString(tiempoTxt, width / 2 - fmTiempo.stringWidth(tiempoTxt) / 2, 47);

            // --- JUGADOR 1 (Izquierda) ---
            g2d.setFont(new Font("Arial", Font.BOLD, 13));
            g2d.setColor(Color.WHITE);
            g2d.drawString(j1.getPais().toUpperCase(), 22, 24);

            g2d.setFont(new Font("Arial", Font.BOLD, 11));
            g2d.drawString("Vida", 22, 43);
            g2d.setColor(new Color(60, 60, 60));
            g2d.fillRoundRect(52, 32, 95, 13, 6, 6);
            g2d.setColor(new Color(46, 204, 113));
            int anchoVida1 = (int) (95 * (j1.getVidaActual() / j1.getVidaMaxima()));
            g2d.fillRoundRect(52, 32, Math.max(0, anchoVida1), 13, 6, 6);

            g2d.setColor(Color.WHITE);
            g2d.drawString("Poder", 158, 43);
            g2d.setColor(new Color(60, 60, 60));
            g2d.fillRoundRect(195, 32, 95, 13, 6, 6);
            g2d.setColor(j1.isTienePoderActivo() ? Color.CYAN : (j1.getBarraPoder() >= 100.0 ? new Color(255, 195, 0) : new Color(52, 152, 219)));
            int anchoPoder1 = (int) (95 * (j1.getBarraPoder() / 100.0));
            g2d.fillRoundRect(195, 32, Math.max(0, anchoPoder1), 13, 6, 6);

            // --- JUGADOR 2 (Derecha) ---
            g2d.setFont(new Font("Arial", Font.BOLD, 13));
            g2d.setColor(Color.WHITE);
            String nombreJ2 = j2.getPais().toUpperCase() + (partido.isContraMaquina() ? " (IA)" : "");
            int anchoNombreJ2 = g2d.getFontMetrics().stringWidth(nombreJ2);
            g2d.drawString(nombreJ2, width - 22 - anchoNombreJ2, 24);

            g2d.setFont(new Font("Arial", Font.BOLD, 11));
            g2d.drawString("Vida", width - 290, 43);
            g2d.setColor(new Color(60, 60, 60));
            g2d.fillRoundRect(width - 260, 32, 95, 13, 6, 6);
            g2d.setColor(new Color(46, 204, 113));
            int anchoVida2 = (int) (95 * (j2.getVidaActual() / j2.getVidaMaxima()));
            g2d.fillRoundRect(width - 260, 32, Math.max(0, anchoVida2), 13, 6, 6);

            g2d.setColor(Color.WHITE);
            g2d.drawString("Poder", width - 155, 43);
            g2d.setColor(new Color(60, 60, 60));
            g2d.fillRoundRect(width - 117, 32, 95, 13, 6, 6);
            g2d.setColor(j2.isTienePoderActivo() ? Color.CYAN : (j2.getBarraPoder() >= 100.0 ? new Color(255, 195, 0) : new Color(52, 152, 219)));
            int anchoPoder2 = (int) (95 * (j2.getBarraPoder() / 100.0));
            g2d.fillRoundRect(width - 117, 32, Math.max(0, anchoPoder2), 13, 6, 6);
        }
    }

    /**
     * Verifica periódicamente si el partido ha terminado para detener el temporizador
     * y desplegar la ventana emergente de resultados.
     */
    private void verificarFinDelPartido() {
        if (partido.isPartidoFinalizado() && gameTimer.isRunning()) {
            gameTimer.stop();
            teclasPresionadas.clear();
            mostrarDialogoResultado();
        }
    }

    /**
     * Construye y muestra un cuadro de diálogo emergente (JDialog) al finalizar el encuentro,
     * mostrando las estadísticas finales, el ganador, los puntos y un botón para continuar.
     */
    private void mostrarDialogoResultado() {
        Jugador j1 = partido.getJugador1();
        Jugador j2 = partido.getJugador2();

        String resultadoTexto = "EMPATE";
        Color colorResultado = Color.ORANGE;
        if (j1.getGoles() > j2.getGoles()) {
            resultadoTexto = "¡VICTORIA DE " + j1.getPais().toUpperCase() + "!";
            colorResultado = new Color(0, 200, 0);
        } else if (j1.getGoles() < j2.getGoles()) {
            resultadoTexto = "¡VICTORIA DE " + j2.getPais().toUpperCase() + "!";
            colorResultado = new Color(220, 20, 60);
        }

        JDialog dialogResultado = new JDialog(this, "RESULTADO", true);
        dialogResultado.setSize(500, 350);
        dialogResultado.setLocationRelativeTo(this);
        dialogResultado.setLayout(new BorderLayout());

        JPanel panelFondo = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2d.setColor(new Color(25, 45, 35));
                g2d.fillRect(0, 0, getWidth(), getHeight());

                g2d.setFont(new Font("Arial", Font.BOLD, 26));
                g2d.setColor(Color.YELLOW);
                g2d.drawString("RESULT", 200, 40);
            }
        };
        panelFondo.setLayout(null);

        JLabel lblEstado = new JLabel(resultadoTexto, SwingConstants.CENTER);
        lblEstado.setFont(new Font("Arial", Font.BOLD, 20));
        lblEstado.setForeground(colorResultado);
        lblEstado.setBounds(50, 60, 400, 30);
        panelFondo.add(lblEstado);

        JLabel lblJ1 = new JLabel(j1.getPais() + " (Goles: " + j1.getGoles() + ")", SwingConstants.CENTER);
        lblJ1.setFont(new Font("Arial", Font.BOLD, 14));
        lblJ1.setForeground(Color.WHITE);
        lblJ1.setBounds(30, 120, 180, 30);
        panelFondo.add(lblJ1);

        JLabel lblVs = new JLabel("VS", SwingConstants.CENTER);
        lblVs.setFont(new Font("Arial", Font.BOLD, 18));
        lblVs.setForeground(Color.YELLOW);
        lblVs.setBounds(220, 120, 60, 30);
        panelFondo.add(lblVs);

        JLabel lblJ2 = new JLabel(j2.getPais() + " (Goles: " + j2.getGoles() + ")", SwingConstants.CENTER);
        lblJ2.setFont(new Font("Arial", Font.BOLD, 14));
        lblJ2.setForeground(Color.WHITE);
        lblJ2.setBounds(290, 120, 180, 30);
        panelFondo.add(lblJ2);

        int puntosGanados = (j1.getGoles() > j2.getGoles()) ? 100 : 25;
        JLabel lblPuntos = new JLabel("REWARD POINT: " + puntosGanados + "   |   TOTAL POINT: " + (j1.getPuntos() + puntosGanados), SwingConstants.CENTER);
        lblPuntos.setFont(new Font("Arial", Font.BOLD, 12));
        lblPuntos.setForeground(Color.LIGHT_GRAY);
        lblPuntos.setBounds(50, 190, 400, 25);
        panelFondo.add(lblPuntos);

        JButton btnNext = new JButton("NEXT");
        btnNext.setFont(new Font("Arial", Font.BOLD, 14));
        btnNext.setBackground(new Color(255, 165, 0));
        btnNext.setForeground(Color.BLACK);
        btnNext.setBounds(180, 240, 140, 35);
        btnNext.addActionListener(e -> {
            dialogResultado.dispose();
            restartGame();
        });
        panelFondo.add(btnNext);

        dialogResultado.add(panelFondo);
        dialogResultado.setVisible(true);
    }

    /**
     * Reinicia el partido actual conservando los países, modalidad y perfil de IA configurados,
     * y asegura que el temporizador del juego se encuentre activo.
     */
    private void restartGame() {
        double ancho = boardPanel.getWidth() > 0 ? boardPanel.getWidth() : 800;
        double alto = boardPanel.getHeight() > 0 ? boardPanel.getHeight() : 500;
        partido = new Partido(ultimoPais1, ultimoPais2, ancho, alto, ultimoTipoFin, ultimoLimite);
        partido.configurarMaquina(ultimoContraMaquina, ultimoPerfilMaquina);
        partido.iniciarPartido();
        teclasPresionadas.clear();
        if (!gameTimer.isRunning()) {
            gameTimer.start();
        }
    }

    /**
     * Muestra un cuadro de confirmación para salir de la aplicación y,
     * en caso afirmativo, finaliza la ejecución del programa.
     */
    private void exit() {
        int option = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea salir?", "Salir", JOptionPane.YES_NO_OPTION);
        if (option == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    /**
     * Abre un selector de archivos del sistema para cargar una partida guardada
     * desde disco utilizando persistencia de objetos.
     */
    private void openFile() {
        if (gameTimer != null && gameTimer.isRunning()) gameTimer.stop();
        JFileChooser fc = new JFileChooser();
        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                partido = Partido.cargar(fc.getSelectedFile());
                partido.actualizarDimensiones(boardPanel.getWidth(), boardPanel.getHeight());
                teclasPresionadas.clear();
                boardPanel.repaint();
                JOptionPane.showMessageDialog(this, "Partida cargada exitosamente.");
            } catch (DOPOSoccerException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al abrir", JOptionPane.ERROR_MESSAGE);
            }
        }
        if (partido != null && !partido.isPartidoFinalizado() && gameTimer != null) {
            gameTimer.start();
        }
    }

    /**
     * Abre un selector de archivos del sistema para guardar el estado de la partida actual
     * utilizando persistencia de objetos.
     */
    private void saveFile() {
        if (partido == null) return;
        if (gameTimer != null && gameTimer.isRunning()) gameTimer.stop();
        JFileChooser fc = new JFileChooser();
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                File archivo = fc.getSelectedFile();
                if (!archivo.getName().endsWith(".dat")) {
                    archivo = new File(archivo.getAbsolutePath() + ".dat");
                }
                partido.guardar(archivo);
                JOptionPane.showMessageDialog(this, "Partida guardada exitosamente en " + archivo.getName());
            } catch (DOPOSoccerException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Error al salvar", JOptionPane.ERROR_MESSAGE);
            }
        }
        if (!partido.isPartidoFinalizado() && gameTimer != null) {
            gameTimer.start();
        }
    }

    /**
     * Método principal de entrada (main) que inicializa la aplicación
     * ejecutando la interfaz gráfica en el hilo de eventos de Swing.
     *
     * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new DOPOSoccerGUI();
        });
    }

    /**
     * Crea y despliega una ventana de diálogo de configuración previa (Player Select)
     * para que el usuario elija la modalidad de juego, el perfil de la máquina, los países
     * de los competidores, el criterio de finalización y el valor límite antes de arrancar.
     */
    private void configurarNuevoPartido() {
        JDialog dialogConfig = new JDialog(this, "DOPOSoccer - Configuración de Partida", true);
        dialogConfig.setSize(460, 420);
        dialogConfig.setLocationRelativeTo(this);
        dialogConfig.setLayout(new GridLayout(7, 2, 10, 10));

        JLabel lblModo = new JLabel("   Modalidad de Juego:");
        String[] modalidades = {"Jugador vs Jugador", "Jugador vs Máquina"};
        JComboBox<String> cmbModo = new JComboBox<>(modalidades);

        JLabel lblPerfil = new JLabel("   Perfil de Máquina:");
        String[] perfiles = {"Torpe", "Ofensiva", "Defensiva", "Experta"};
        JComboBox<String> cmbPerfil = new JComboBox<>(perfiles);
        cmbPerfil.setSelectedItem("Ofensiva");
        cmbPerfil.setEnabled(false);

        cmbModo.addActionListener(e -> cmbPerfil.setEnabled(cmbModo.getSelectedIndex() == 1));

        JLabel lblPais1 = new JLabel("   País Jugador 1 (J1):");
        String[] paises = {"Corea del Sur", "Camerún", "Nigeria", "Estados Unidos", "Colombia", "Brasil", "Argentina", "España", "México"};
        JComboBox<String> cmbPais1 = new JComboBox<>(paises);

        JLabel lblPais2 = new JLabel("   País Jugador 2 / Máquina:");
        JComboBox<String> cmbPais2 = new JComboBox<>(paises);
        cmbPais2.setSelectedItem("Camerún");

        JLabel lblTipoFin = new JLabel("   Condición de Fin:");
        String[] tiposFin = {"Por Tiempo (Minutos)", "Por Goles (Meta)"};
        JComboBox<String> cmbTipoFin = new JComboBox<>(tiposFin);

        JLabel lblValorFin = new JLabel("   Valor (Minutos o Goles):");
        JTextField txtValorFin = new JTextField("3");

        JButton btnIniciar = new JButton("¡PLAY!");
        btnIniciar.setBackground(new Color(255, 165, 0));
        btnIniciar.setForeground(Color.BLACK);
        btnIniciar.setFont(new Font("Arial", Font.BOLD, 14));

        btnIniciar.addActionListener(e -> {
            ultimoPais1 = (String) cmbPais1.getSelectedItem();
            ultimoPais2 = (String) cmbPais2.getSelectedItem();
            ultimoContraMaquina = (cmbModo.getSelectedIndex() == 1);
            ultimoPerfilMaquina = (String) cmbPerfil.getSelectedItem();

            ultimoTipoFin = (cmbTipoFin.getSelectedIndex() == 0) ? "tiempo" : "goles";
            try {
                ultimoLimite = Integer.parseInt(txtValorFin.getText().trim());
                if (ultimoLimite <= 0) ultimoLimite = 3;
            } catch (NumberFormatException ex) {
                ultimoLimite = 3;
            }

            double ancho = boardPanel.getWidth() > 0 ? boardPanel.getWidth() : 800;
            double alto = boardPanel.getHeight() > 0 ? boardPanel.getHeight() : 500;

            partido = new Partido(ultimoPais1, ultimoPais2, ancho, alto, ultimoTipoFin, ultimoLimite);
            partido.configurarMaquina(ultimoContraMaquina, ultimoPerfilMaquina);
            partido.iniciarPartido();
            teclasPresionadas.clear();

            if (gameTimer != null && !gameTimer.isRunning()) {
                gameTimer.start();
            }
            dialogConfig.dispose();
        });

        dialogConfig.add(lblModo);
        dialogConfig.add(cmbModo);
        dialogConfig.add(lblPerfil);
        dialogConfig.add(cmbPerfil);
        dialogConfig.add(lblPais1);
        dialogConfig.add(cmbPais1);
        dialogConfig.add(lblPais2);
        dialogConfig.add(cmbPais2);
        dialogConfig.add(lblTipoFin);
        dialogConfig.add(cmbTipoFin);
        dialogConfig.add(lblValorFin);
        dialogConfig.add(txtValorFin);
        dialogConfig.add(new JLabel(""));
        dialogConfig.add(btnIniciar);

        dialogConfig.setVisible(true);
    }
}