package dominio;

import java.io.*;
import java.util.Random;

/**
 * Representa un partido de juego en el simulador DOPOSoccer.
 * Se encarga de coordinar a los jugadores, el balón, la lógica de actualización
 * de físicas, la inteligencia artificial de la máquina, la detección de colisiones,
 * los tiros de poder y sus efectos, el registro de goles, la persistencia y el
 * control de las condiciones de victoria.
 */
public class Partido implements Serializable {
    private static final long serialVersionUID = 1L;

    /** Instancia del primer jugador participante. */
    private Jugador jugador1;

    /** Instancia del segundo jugador participante. */
    private Jugador jugador2;

    /** Instancia del balón del partido. */
    private Balon balon;

    /** Indica si el partido se encuentra activo y en curso. */
    private boolean enJuego;

    /** Indica si el partido ha finalizado. */
    private boolean partidoFinalizado;

    /** Ancho total de la cancha de juego. */
    private double anchoCancha;

    /** Alto total de la cancha de juego. */
    private double altoCancha;

    // Nuevos atributos para las reglas de finalización
    /** Tipo de criterio para finalizar el partido ("goles" o "tiempo"). */
    private String tipoFin; // "goles" o "tiempo"

    /** Cantidad límite de goles requerida para ganar (si aplica). */
    private int limiteGoles;

    /** Duración máxima del partido en minutos (si aplica). */
    private int tiempoMaximoMinutos; // O en segundos para mayor control

    /** Contador acumulado de los segundos transcurridos en el encuentro. */
    private double segundosTranscurridos;

    /** Indica si el segundo jugador es controlado por la máquina (IA). */
    private boolean contraMaquina;

    /** Perfil de comportamiento de la máquina ("Torpe", "Ofensiva", "Defensiva", "Experta"). */
    private String perfilMaquina;

    /** Generador aleatorio para decisiones de la IA. */
    private Random random;

    /** Indica si el balón lleva actualmente un tiro de poder activo. */
    private boolean tiroPoderActivo = false;

    /** Jugador que ejecutó el tiro de poder activo. */
    private Jugador autorTiroPoder = null;

    /** Coordenadas [7][2] (x, y) y velocidades [7][2] (vx, vy) de los 7 balones falsos de Ilusión. */
    private double[][] balonesFalsos = null;
    private double[][] velBalonesFalsos = null;
    private double tiempoIlusionRestante = 0.0;

    /**
     * Constructor para inicializar una nueva instancia del partido configurando
     * las dimensiones del campo, los países de los jugadores y las reglas de victoria.
     *
     * @param pais1 País o selección del primer jugador.
     * @param pais2 País o selección del segundo jugador.
     * @param ancho Ancho total de la cancha.
     * @param alto  Alto total de la cancha.
     * @param tipoFin Modo de finalización del juego ("goles" o "tiempo").
     * @param limite Valor límite de goles o minutos según el modo escogido.
     */
    public Partido(String pais1, String pais2, double ancho, double alto, String tipoFin, int limite) {
        this.anchoCancha = ancho;
        this.altoCancha = alto;
        double sueloY = alto - 50.0;

        this.jugador1 = new Jugador(pais1, 100, sueloY - 70, 5, 5, 5, 5);
        this.jugador2 = new Jugador(pais2, ancho - 140, sueloY - 70, 5, 5, 5, 5);
        this.balon = new Balon(ancho / 2.0, alto / 2.0);

        this.enJuego = false;
        this.partidoFinalizado = false;

        this.tipoFin = tipoFin; // "goles" o "tiempo"
        if (tipoFin.equalsIgnoreCase("goles")) {
            this.limiteGoles = limite;
        } else {
            this.tiempoMaximoMinutos = limite; // ej: 3 minutos
            this.segundosTranscurridos = 0;
        }

        this.contraMaquina = false;
        this.perfilMaquina = "Ofensiva";
        this.random = new Random();
    }

    /**
     * Actualiza las dimensiones lógicas de la cancha cuando la ventana cambia de tamaño
     * (por ejemplo, al maximizar a pantalla completa), ajustando el suelo para evitar
     * que los jugadores queden flotando.
     *
     * @param nuevoAncho Nuevo ancho del panel de juego.
     * @param nuevoAlto  Nuevo alto del panel de juego.
     */
    public void actualizarDimensiones(double nuevoAncho, double nuevoAlto) {
        if (nuevoAncho <= 0 || nuevoAlto <= 0) return;
        double sueloAnterior = this.altoCancha - 50.0;
        double nuevoSuelo = nuevoAlto - 50.0;

        this.anchoCancha = nuevoAncho;
        this.altoCancha = nuevoAlto;

        // Si estaban apoyados en el suelo anterior, los reubica exactamente en el nuevo suelo
        if (Math.abs((jugador1.getY() + jugador1.getAlto()) - sueloAnterior) < 15) {
            jugador1.reiniciarPosicion(Math.min(jugador1.getX(), nuevoAncho - jugador1.getAncho()), nuevoSuelo - jugador1.getAlto());
        }
        if (Math.abs((jugador2.getY() + jugador2.getAlto()) - sueloAnterior) < 15) {
            jugador2.reiniciarPosicion(Math.min(jugador2.getX(), nuevoAncho - jugador2.getAncho()), nuevoSuelo - jugador2.getAlto());
        }
        if (balon.getY() > nuevoSuelo - balon.getRadio()) {
            balon.setY(nuevoSuelo - balon.getRadio());
        }
    }

    /**
     * Configura si el partido se juega contra la máquina y establece su perfil de IA.
     *
     * @param contraMaquina True para activar IA en el jugador 2, false para 2 jugadores humanos.
     * @param perfilMaquina Perfil de la IA ("Torpe", "Ofensiva", "Defensiva", "Experta").
     */
    public void configurarMaquina(boolean contraMaquina, String perfilMaquina) {
        this.contraMaquina = contraMaquina;
        this.perfilMaquina = (perfilMaquina != null) ? perfilMaquina : "Ofensiva";
    }

    /**
     * Inicia formalmente el partido cambiando el estado de juego a activo.
     */
    public void iniciarPartido() {
        this.enJuego = true;
    }

    /**
     * Actualiza el estado lógico del partido fotograma a fotograma, gestionando
     * el tiempo restante, la IA (si aplica), las físicas del balón y jugadores,
     * los tiros de poder, las colisiones y la detección de goles.
     */
    public void actualizar() {
        if (!enJuego || partidoFinalizado) return;

        if ("tiempo".equalsIgnoreCase(tipoFin)) {
            segundosTranscurridos += (16.0 / 1000.0);
            if (segundosTranscurridos >= (tiempoMaximoMinutos * 60)) {
                partidoFinalizado = true;
                enJuego = false;
                return;
            }
        }

        if (contraMaquina) {
            actualizarIA();
        }

        double sueloY = this.altoCancha - 50.0;
        this.balon.mover(this.anchoCancha, sueloY);

        // Si es tiro de poder de Aura Azul (Corea del Sur) o Rayo (Camerún), mantener trayectoria horizontal
        if (tiroPoderActivo && autorTiroPoder != null) {
            String paisAutor = autorTiroPoder.getPais();
            if ("Corea del Sur".equalsIgnoreCase(paisAutor) || "Corea".equalsIgnoreCase(paisAutor)
                    || "Camerún".equalsIgnoreCase(paisAutor)) {
                balon.aplicarImpulso(0.0, -0.65);
            }
        }

        jugador1.actualizarFisica(sueloY);
        jugador2.actualizarFisica(sueloY);

        // Actualizar efectos visuales de patada
        jugador1.actualizarEfectoPatada();
        jugador2.actualizarEfectoPatada();

        verificarColisionJugadorBalon(jugador1);
        verificarColisionJugadorBalon(jugador2);

        // Detección de goles
        double bx = balon.getX();
        double by = balon.getY();
        double altoArcos = 150.0;

        if (bx <= 20 && by >= sueloY - altoArcos && by <= sueloY) {
            registrarGol(2);
        } else if (bx >= anchoCancha - 20 && by >= sueloY - altoArcos && by <= sueloY) {
            registrarGol(1);
        }

        actualizarBalonesFalsos(sueloY);
    }

    /**
     * Controla automáticamente los movimientos, saltos y patadas del Jugador 2
     * según el perfil de inteligencia artificial seleccionado.
     */
    private void actualizarIA() {
        if (jugador2.isAturdido()) return;

        double bx = balon.getX();
        double by = balon.getY();
        double j2x = jugador2.getX();
        double j2y = jugador2.getY();
        double distanciaX = bx - j2x;

        if ("Torpe".equalsIgnoreCase(perfilMaquina)) {
            int accion = random.nextInt(20);
            if (accion < 4) jugador2.moverIzquierda(0);
            else if (accion < 8) jugador2.moverDerecha(anchoCancha);
            else if (accion == 9) jugador2.saltar();
            else if (accion == 10) patear(jugador2);
            return;
        }

        if ("Defensiva".equalsIgnoreCase(perfilMaquina)) {
            double zonaDefensa = anchoCancha * 0.72;
            if (bx < anchoCancha * 0.5) {
                if (j2x < zonaDefensa - 10) jugador2.moverDerecha(anchoCancha);
                else if (j2x > zonaDefensa + 10) jugador2.moverIzquierda(0);
            } else {
                if (bx < j2x + 10) jugador2.moverIzquierda(0);
                else jugador2.moverDerecha(anchoCancha);
            }
            if (Math.abs(distanciaX) < 55 && by < j2y + 20) jugador2.saltar();
            if (Math.abs(distanciaX) < 50 && Math.abs(by - j2y) < 60) patear(jugador2);
            return;
        }

        if ("Experta".equalsIgnoreCase(perfilMaquina)) {
            boolean vaPerdiendo = jugador2.getGoles() < jugador1.getGoles();
            double objetivoX = (bx > anchoCancha * 0.85) ? anchoCancha - 45 : bx + 15;

            if (objetivoX < j2x) jugador2.moverIzquierda(0);
            else if (objetivoX > j2x + 10) jugador2.moverDerecha(anchoCancha);

            if (Math.abs(distanciaX) < 65 && by < j2y - 10) jugador2.saltar();
            if (Math.abs(distanciaX) < 55 && Math.abs(by - (j2y + 35)) < 45) {
                patear(jugador2);
                if (vaPerdiendo && jugador2.getBarraPoder() >= 100.0) {
                    jugador2.usarPoder();
                }
            }
            return;
        }

        // Perfil por defecto: "Ofensiva"
        if (bx < j2x + 10) {
            jugador2.moverIzquierda(0);
        } else if (bx > j2x + 25) {
            jugador2.moverDerecha(anchoCancha);
        }
        if (Math.abs(distanciaX) < 60 && by < j2y) {
            jugador2.saltar();
        }
        if (Math.abs(distanciaX) < 50 && Math.abs(by - (j2y + 35)) < 50) {
            patear(jugador2);
        }
    }

    /**
     * Verifica y procesa la colisión física entre un jugador específico y el balón,
     * ejecutando su tiro de poder si tiene aura activa, aplicando daño/efecto si
     * recibe un tiro de poder rival o aplicando impulso normal de colisión.
     *
     * @param j Instancia del jugador a evaluar.
     */
    private void verificarColisionJugadorBalon(Jugador j) {
        double bx = balon.getX();
        double by = balon.getY();
        double radioBalon = balon.getRadio();
        double jx = j.getX();
        double jy = j.getY();
        double jAncho = j.getAncho();
        double jAlto = j.getAlto();

        if (bx + radioBalon >= jx && bx - radioBalon <= jx + jAncho &&
            by + radioBalon >= jy && by - radioBalon <= jy + jAlto) {

            double direccion = (bx < jx + jAncho / 2.0) ? -1.0 : 1.0;

            // Si el balón lleva un tiro de poder activo y toca al rival, aplica daño y efecto
            if (tiroPoderActivo && autorTiroPoder != null && j != autorTiroPoder) {
                aplicarImpactoTiroPoder(j);
                return;
            }

            // Si este jugador tiene poder activo (aura), ejecuta su tiro de poder al tocar el balón
            if (j.isTienePoderActivo()) {
                double dirTiro = (j == jugador1) ? 1.0 : -1.0;
                activarTiroPoderEnBalon(j, dirTiro, altoCancha - 50.0);
                return;
            }

            double fuerzaKick = j.obtenerMultiplicadorKick();
            // Impulso más controlado para que el balón ruede y no salga volando tan fácil
            balon.aplicarImpulso(direccion * (4.2 * fuerzaKick), -4.5);
            if (direccion < 0) {
                balon.setX(jx - radioBalon - 2);
            } else {
                balon.setX(jx + jAncho + radioBalon + 2);
            }
        }
    }

    /**
     * Aplica el daño escalado y el efecto de estado al rival golpeado por un tiro de poder.
     *
     * @param rival Jugador rival que recibe el impacto del tiro de poder.
     */
    private void aplicarImpactoTiroPoder(Jugador rival) {
        double danioPoder = autorTiroPoder.obtenerDanioBasePoder() * autorTiroPoder.obtenerMultiplicadorKick();
        String efecto = autorTiroPoder.obtenerEfectoPoderPorPais();
        double duracion = autorTiroPoder.obtenerDuracionEfectoPoder();
        boolean rivalEsJ1 = (rival == jugador1);

        rival.recibirDanio(danioPoder);
        rival.aplicarEfectoPoder(efecto, duracion, rivalEsJ1);

        tiroPoderActivo = false;
        autorTiroPoder = null;
    }

    /**
     * Registra un gol a favor del jugador indicado, evalúa si se cumplió la condición
     * de victoria por goles y reinicia la posición del balón y jugadores en la cancha.
     *
     * @param numeroJugador Número del jugador que anota (1 o 2).
     */
    public void registrarGol(int numeroJugador) {
        // Si entra al arco sin golpear al rival, el gol cuenta sin daño ni efecto; limpiamos estado de tiro
        this.tiroPoderActivo = false;
        this.autorTiroPoder = null;
        this.balonesFalsos = null;
        this.velBalonesFalsos = null;
        this.tiempoIlusionRestante = 0.0;

        if (numeroJugador == 1) {
            jugador1.sumarGol();
            jugador2.setBarraPoder(Math.min(100.0, jugador2.getBarraPoder() + 25.0));
        } else {
            jugador2.sumarGol();
            jugador1.setBarraPoder(Math.min(100.0, jugador1.getBarraPoder() + 25.0));
        }

        // Verificar si se alcanzó el límite de goles para ganar
        if ("goles".equalsIgnoreCase(tipoFin)) {
            if (jugador1.getGoles() >= limiteGoles || jugador2.getGoles() >= limiteGoles) {
                partidoFinalizado = true;
                enJuego = false;
                return;
            }
        }

        double sueloY = altoCancha - 50.0;
        jugador1.reiniciarPosicion(100, sueloY - 70);
        jugador2.reiniciarPosicion(anchoCancha - 140, sueloY - 70);
        balon.reiniciar(anchoCancha / 2.0, altoCancha / 2.0);
    }

    /**
     * Permite a un jugador realizar una patada activa sobre el balón o el rival
     * y activa su efecto visual. Si tiene poder activo y toca el balón, ejecuta su tiro de poder.
     *
     * @param j Instancia del jugador que ejecuta la patada.
     */
    public void patear(Jugador j) {
        if (j == null || j.isAturdido() || j.isInconsciente()) return;

        j.activarPatadaVisual(); // Activa la animación de patada

        double bx = balon.getX();
        double by = balon.getY();
        double radioBalon = balon.getRadio();
        double jx = j.getX();
        double jy = j.getY();
        double jAncho = j.getAncho();
        double jAlto = j.getAlto();

        // Impulsar balón o disparar tiro de poder si está dentro del alcance
        if (bx + radioBalon + 18 >= jx && bx - radioBalon - 18 <= jx + jAncho &&
            by + radioBalon >= jy && by - radioBalon <= jy + jAlto) {

            if (j.isTienePoderActivo()) {
                double dirTiro = (j == jugador1) ? 1.0 : -1.0;
                activarTiroPoderEnBalon(j, dirTiro, altoCancha - 50.0);
            } else {
                double direccion = (bx < jx + jAncho / 2.0) ? -1.0 : 1.0;
                double fuerzaKick = j.obtenerMultiplicadorKick();
                balon.aplicarImpulso(direccion * (7.5 * fuerzaKick), -6.5);
            }
        }

        // Daño por patada normal al rival si está dentro del alcance del pie
        Jugador rival = (j == jugador1) ? jugador2 : jugador1;
        if (rival != null) {
            double rx = rival.getX();
            double ry = rival.getY();
            double rAncho = rival.getAncho();
            double rAlto = rival.getAlto();

            boolean rivalEnAlcance =
                rx + rAncho + 18 >= jx && rx - 18 <= jx + jAncho &&
                ry + rAlto >= jy && ry <= jy + jAlto;

            if (rivalEnAlcance) {
                double danioPatada = 10.0 * j.obtenerMultiplicadorKick();
                rival.recibirDanio(danioPatada);
            }
        }
    }

    /**
     * Dispara el tiro de poder del jugador cuando toca el balón, consume su aura
     * y configura la trayectoria o balones falsos según su país.
     *
     * @param autor     Jugador que ejecuta el tiro de poder.
     * @param direccion Dirección horizontal del tiro (+1 derecha, -1 izquierda).
     * @param sueloY    Coordenada Y del suelo de la cancha.
     */
    private void activarTiroPoderEnBalon(Jugador autor, double direccion, double sueloY) {
        autor.consumirPoderAlTocarBalon();
        this.tiroPoderActivo = true;
        this.autorTiroPoder = autor;

        String pais = autor.getPais();
        double multKick = autor.obtenerMultiplicadorKick();

        if ("Corea del Sur".equalsIgnoreCase(pais) || "Corea".equalsIgnoreCase(pais)) {
            // Aura Azul: recto y horizontal, a alta velocidad
            balon.reiniciar(balon.getX(), balon.getY());
            balon.aplicarImpulso(direccion * 14.0, 0.0);
        } else if ("Camerún".equalsIgnoreCase(pais)) {
            // Rayo: recto, cubierto de electricidad
            balon.reiniciar(balon.getX(), balon.getY());
            balon.aplicarImpulso(direccion * 12.5, 0.0);
        } else if ("Nigeria".equalsIgnoreCase(pais)) {
            // Tornado: remolino a ras de suelo que rebota rápidamente
            balon.setY(sueloY - balon.getRadio());
            balon.aplicarImpulso(direccion * 10.0, -7.5);
        } else if ("Estados Unidos".equalsIgnoreCase(pais)) {
            // Ilusión: el balón se divide en 8 balones idénticos (1 real + 7 falsos)
            balon.aplicarImpulso(direccion * (8.5 * multKick), -5.0);
            this.balonesFalsos = new double[7][2];
            this.velBalonesFalsos = new double[7][2];
            this.tiempoIlusionRestante = 2.5;
            for (int i = 0; i < 7; i++) {
                balonesFalsos[i][0] = balon.getX() + (i - 3) * 18.0;
                balonesFalsos[i][1] = balon.getY() + ((i % 2 == 0) ? -14.0 : 14.0);
                velBalonesFalsos[i][0] = direccion * (7.0 + random.nextDouble() * 4.0);
                velBalonesFalsos[i][1] = -4.0 + random.nextDouble() * 8.0;
            }
        }
    }

    /**
     * Actualiza el movimiento de los 7 balones falsos y limpia la ilusión al terminar su duración.
     *
     * @param sueloY Coordenada Y del suelo de la cancha.
     */
    private void actualizarBalonesFalsos(double sueloY) {
        if (balonesFalsos == null) return;
        tiempoIlusionRestante -= (16.0 / 1000.0);
        if (tiempoIlusionRestante <= 0.0) {
            balonesFalsos = null;
            velBalonesFalsos = null;
            tiempoIlusionRestante = 0.0;
            return;
        }
        for (int i = 0; i < balonesFalsos.length; i++) {
            velBalonesFalsos[i][1] += 0.65;
            balonesFalsos[i][0] += velBalonesFalsos[i][0];
            balonesFalsos[i][1] += velBalonesFalsos[i][1];
            if (balonesFalsos[i][1] >= sueloY - balon.getRadio()) {
                balonesFalsos[i][1] = sueloY - balon.getRadio();
                velBalonesFalsos[i][1] = -Math.abs(velBalonesFalsos[i][1]) * 0.6;
            }
            if (balonesFalsos[i][0] <= balon.getRadio() || balonesFalsos[i][0] >= anchoCancha - balon.getRadio()) {
                velBalonesFalsos[i][0] = -velBalonesFalsos[i][0];
            }
        }
    }

    /**
     * Guarda el estado completo del partido actual en un archivo binario.
     *
     * @param archivo Archivo destino donde se serializará el partido.
     * @throws DOPOSoccerException Si ocurre un error de entrada/salida al guardar.
     */
    public void guardar(File archivo) throws DOPOSoccerException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
            oos.writeObject(this);
        } catch (IOException e) {
            throw new DOPOSoccerException("No se pudo guardar la partida en el archivo: " + archivo.getName(), e);
        }
    }

    /**
     * Carga y reconstruye una instancia de partido previamente guardada desde un archivo.
     *
     * @param archivo Archivo fuente desde donde se leerá el partido.
     * @return Instancia recuperada de {@link Partido}.
     * @throws DOPOSoccerException Si el archivo no existe, está corrupto o es incompatible.
     */
    public static Partido cargar(File archivo) throws DOPOSoccerException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return (Partido) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new DOPOSoccerException("No se pudo abrir la partida desde el archivo: " + archivo.getName(), e);
        }
    }

    // Getters necesarios para la GUI
    /**
     * Indica si el partido ha terminado.
     *
     * @return True si finalizó, false en caso contrario.
     */
    public boolean isPartidoFinalizado() { return partidoFinalizado; }

    /**
     * Obtiene una cadena de texto formateada con el tiempo restante del partido
     * o la meta de goles establecida.
     *
     * @return Texto descriptivo del tiempo o modo de juego.
     */
    public String getTiempoRestanteFormateado() {
        if ("goles".equalsIgnoreCase(tipoFin)) return "Modo Goles (Meta: " + limiteGoles + ")";
        double segundosTotales = (tiempoMaximoMinutos * 60) - segundosTranscurridos;
        if (segundosTotales < 0) segundosTotales = 0;
        int min = (int) (segundosTotales / 60);
        int seg = (int) (segundosTotales % 60);
        return String.format("Tiempo: %02d:%02d", min, seg);
    }

    /** @return Coordenadas de los 7 balones falsos si está activa la ilusión, o null. */
    public double[][] getBalonesFalsos() { return balonesFalsos; }

    /** @return Instancia del jugador 1. */
    public Jugador getJugador1() { return jugador1; }

    /** @return Instancia del jugador 2. */
    public Jugador getJugador2() { return jugador2; }

    /** @return Instancia del balón. */
    public Balon getBalon() { return balon; }

    /** @return True si el partido está en curso, false si está detenido o finalizado. */
    public boolean isEnJuego() { return enJuego; }

    /** @return True si el partido es contra la máquina, false si es Jugador vs Jugador. */
    public boolean isContraMaquina() { return contraMaquina; }

    /** @return Nombre del perfil de IA configurado. */
    public String getPerfilMaquina() { return perfilMaquina; }
}