package dominio;

import java.io.Serializable;

/**
 * Representa el balón de juego dentro del simulador DOPOSoccer.
 * Se encarga de gestionar su posición, velocidades, físicas de movimiento,
 * gravedad y las colisiones con los límites de la cancha y el suelo.
 */
public class Balon implements Serializable {
    private static final long serialVersionUID = 1L;

    /** Posición actual del balón en el eje X. */
    private double x;
    
    /** Posición actual del balón en el eje Y. */
    private double y;
    
    /** Velocidad actual de desplazamiento en el eje X. */
    private double velocidadX;
    
    /** Velocidad actual de desplazamiento en el eje Y. */
    private double velocidadY;
    
    /** Radio del balón, utilizado para cálculos de colisión y rebotes. */
    private double radio;
    
    /** Fuerza de gravedad constante que afecta la velocidad vertical del balón. */
    private double gravedad;

    /**
     * Constructor para inicializar una nueva instancia del balón en una posición específica.
     * 
     * @param posXInicial Posición inicial en el eje X.
     * @param posYInicial Posición inicial en el eje Y.
     */
    public Balon(double posXInicial, double posYInicial) {
        this.x = posXInicial;
        this.y = posYInicial;
        this.velocidadX = 0.0;
        this.velocidadY = 0.0;
        this.radio = 12.0;
        this.gravedad = 0.65; // Gravedad más realista para que no flote tanto
    }

    /**
     * Actualiza la posición y velocidad del balón en cada fotograma, aplicando gravedad,
     * fricción y evaluando los rebotes contra el suelo y los bordes laterales de la cancha.
     * 
     * @param anchoCancha Ancho total de la cancha de juego.
     * @param sueloY      Coordenada Y que representa la altura del suelo.
     */
    public void mover(double anchoCancha, double sueloY) {
        // Aplicar gravedad
        this.velocidadY += this.gravedad;

        // Limitar velocidad máxima para mantener control realista
        if (this.velocidadX > 14) this.velocidadX = 14;
        if (this.velocidadX < -14) this.velocidadX = -14;
        if (this.velocidadY > 18) this.velocidadY = 18;
        if (this.velocidadY < -15) this.velocidadY = -15;

        // Actualizar coordenadas
        this.x += this.velocidadX;
        this.y += this.velocidadY;

        // Rebote y rodamiento en el suelo
        if (this.y >= sueloY - this.radio) {
            this.y = sueloY - this.radio;
            
            // Si el impacto vertical es muy suave, deja de rebotar y rueda por el césped
            if (Math.abs(this.velocidadY) < 2.2) {
                this.velocidadY = 0;
            } else {
                this.velocidadY = -this.velocidadY * 0.55; // Rebote amortiguado realista
            }
            
            this.velocidadX *= 0.92; // Fricción con el césped
            if (Math.abs(this.velocidadX) < 0.15) {
                this.velocidadX = 0;
            }
        } else {
            // Ligera resistencia del aire
            this.velocidadX *= 0.992;
        }

        // Rebote en los bordes laterales
        if (this.x <= this.radio) {
            this.x = this.radio;
            this.velocidadX = -this.velocidadX * 0.65;
        } else if (this.x >= anchoCancha - this.radio) {
            this.x = anchoCancha - this.radio;
            this.velocidadX = -this.velocidadX * 0.65;
        }
    }

    /**
     * Restablece la posición del balón a unas coordenadas dadas (como el centro de la cancha)
     * y reinicia sus velocidades a cero.
     * 
     * @param centroX Nueva coordenada X de reinicio.
     * @param centroY Nueva coordenada Y de reinicio.
     */
    public void reiniciar(double centroX, double centroY) {
        this.x = centroX;
        this.y = centroY;
        this.velocidadX = 0.0;
        this.velocidadY = 0.0;
    }

    /**
     * Aplica un vector de fuerza externa sobre el balón para alterar su velocidad actual
     * (por ejemplo, al ser golpeado por un jugador).
     * 
     * @param fuerzaX Fuerza a aplicar en el eje X.
     * @param fuerzaY Fuerza a aplicar en el eje Y.
     */
    public void aplicarImpulso(double fuerzaX, double fuerzaY) {
        this.velocidadX += fuerzaX;
        this.velocidadY += fuerzaY;
    }

    /**
     * Obtiene la posición actual del balón en el eje X.
     * 
     * @return Coordenada X del balón.
     */
    public double getX() { return x; }

    /**
     * Obtiene la posición actual del balón en el eje Y.
     * 
     * @return Coordenada Y del balón.
     */
    public double getY() { return y; }

    /**
     * Modifica directamente la posición del balón en el eje X.
     * 
     * @param x Nueva coordenada X.
     */
    public void setX(double x) { this.x = x; }

    /**
     * Modifica directamente la posición del balón en el eje Y.
     * 
     * @param y Nueva coordenada Y.
     */
    public void setY(double y) { this.y = y; }

    /**
     * Obtiene el radio del balón (utilizado para cálculos de colisión).
     * 
     * @return Radio del balón.
     */
    public double getRadio() { return radio; }
}