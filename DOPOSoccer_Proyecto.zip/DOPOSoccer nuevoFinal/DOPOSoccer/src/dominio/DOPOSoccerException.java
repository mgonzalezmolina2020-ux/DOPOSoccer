package dominio;

/**
 * Excepción personalizada para manejar errores específicos de la lógica
 * y persistencia del simulador DOPOSoccer.
 */
public class DOPOSoccerException extends Exception {

    /**
     * Constructor que crea una nueva excepción con un mensaje descriptivo.
     * 
     * @param mensaje Descripción detallada del error ocurrido.
     */
    public DOPOSoccerException(String mensaje) {
        super(mensaje);
    }

    /**
     * Constructor que crea una nueva excepción encapsulando una causa original.
     * 
     * @param mensaje Descripción detallada del error ocurrido.
     * @param causa   Excepción original que desencadenó el fallo.
     */
    public DOPOSoccerException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}