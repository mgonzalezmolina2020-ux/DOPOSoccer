package dominio;

import java.io.Serializable;

/**
 * Representa a un jugador dentro del juego DOPOSoccer.
 * Gestiona sus estadísticas de atributos,
 * su posición en la cancha, estado de salud, goles, puntos y habilidades especiales.
 */
public class Jugador implements Serializable {
    private static final long serialVersionUID = 1L;

    /** País o nacionalidad que representa el jugador. */
    private String pais;
    
    /** Cantidad total de goles anotados por el jugador en el partido. */
    private int goles;
    
    /** Puntos de vida actuales del jugador. */
    private double vidaActual;
    
    /** Nivel de carga actual de la barra de poder especial. */
    private double barraPoder;
    
    /** Indica si el jugador tiene un poder especial activado en este momento. */
    private boolean tienePoderActivo;
    
    /** Nombre o tipo de poder activo (aura) actual que posee el jugador. */
    private String poderActivo; // Representa el poder activo (aura) actual
    
    /** Atributo de velocidad de movimiento del jugador. */
    private int speed;
    
    /** Atributo de fuerza o altura de salto del jugador. */
    private int jump;
    
    /** Atributo de potencia de patada del jugador. */
    private int kick;

    /** Contador de fotogramas para mostrar el efecto visual temporal de la patada. */
    private int framesEfectoPatada = 0;
    
    /** Atributo de resistencia o supervivencia que escala su vida máxima. */
    private int survival;
    
    /** Puntos acumulados por el jugador durante la partida. */
    private int puntos;

    /** Indica si el jugador está aturdido por llegar su vida a cero. */
    private boolean aturdido;

    /** Efecto recibido de un tiro de poder rival ("Ninguno", "Empuje", "Electrocutado", "Inconsciente", "Confusión"). */
    private String efectoRecibido = "Ninguno";

    /** Tiempo restante del efecto recibido en segundos. */
    private double tiempoEfectoRestante = 0.0;

    /** Tiempo restante de aturdimiento en segundos (duración total: 3.0 segundos). */
    private double tiempoAturdidoRestante;

    // Coordenadas y dimensiones del avatar en la cancha
    /** Posición actual del jugador en el eje X. */
    private double x;
    
    /** Posición actual del jugador en el eje Y. */
    private double y;
    
    /** Ancho del rectángulo de colisión del avatar. */
    private double ancho;
    
    /** Alto del rectángulo de colisión del avatar. */
    private double alto;
    
    /** Velocidad vertical actual (afectada por saltos y gravedad). */
    private double velocidadY;
    
    /** Bandera que indica si el jugador se encuentra apoyado sobre el suelo. */
    private boolean enSuelo;

    /**
     * Constructor para inicializar una nueva instancia del jugador con sus 
     * coordenadas de aparición y estadísticas base.
     * 
     * @param pais     País o selección que representa el jugador.
     * @param xInicial Posición inicial en el eje X.
     * @param yInicial Posición inicial en el eje Y.
     * @param speed    Valor de velocidad base.
     * @param jump     Valor de salto base.
     * @param kick     Valor de potencia de patada.
     * @param survival Valor de supervivencia (determina la vida máxima).
     */
    public Jugador(String pais, double xInicial, double yInicial, int speed, int jump, int kick, int survival) {
        this.pais = pais;
        this.x = xInicial;
        this.y = yInicial;
        this.ancho = 40;
        this.alto = 70;
        
        // Inicialización solicitada en los requisitos:
        this.goles = 0;                    // Marcador en 0
        this.barraPoder = 0.0;             // Barra de poder vacía
        this.tienePoderActivo = false;     // Sin poder activo al iniciar
        this.poderActivo = "Ninguno";      // Poder inicial
        this.puntos = 0;                   // Puntos acumulados en 0
        
        this.speed = speed;
        this.jump = jump;
        this.kick = kick;
        this.survival = survival;
        
        this.vidaActual = getVidaMaxima(); // Vida en su máximo
        this.velocidadY = 0;
        this.enSuelo = true;

        this.aturdido = false;
        this.tiempoAturdidoRestante = 0.0;
        this.efectoRecibido = "Ninguno";
        this.tiempoEfectoRestante = 0.0;
    }

    /**
     * Restablece la posición del jugador a sus coordenadas iniciales (por ejemplo, tras un gol).
     * 
     * @param xInicial Coordenada X de reinicio.
     * @param yInicial Coordenada Y de reinicio.
     */
    public void reiniciarPosicion(double xInicial, double yInicial) {
        this.x = xInicial;
        this.y = yInicial;
        this.velocidadY = 0;
        this.enSuelo = true;
    }

    /**
     * Calcula y retorna la vida máxima que puede tener el jugador basada 
     * en su atributo de supervivencia (survival).
     * 
     * @return Valor máximo de vida calculado.
     */
    public double getVidaMaxima() {
        return 100 * (1 + 0.10 * (this.survival - 1));
    }

    /**
     * Calcula y retorna el multiplicador de fuerza aplicado a los golpes 
     * o patadas basado en el atributo de patada (kick).
     * 
     * @return Factor multiplicador para el impulso del balón.
     */
    public double obtenerMultiplicadorKick() {
        return 1 + 0.10 * (this.kick - 1);
    }

    /**
     * Desplaza al jugador hacia la izquierda en la cancha, respetando un límite inferior.
     * 
     * @param limiteIzq Coordenada mínima permitida en el eje X (borde izquierdo).
     */
    public void moverIzquierda(double limiteIzq) {
        if (aturdido || isInconsciente()) return;
        double factorVelocidad = isElectrocutado() ? 0.5 : 1.0;
        this.x -= (5.0 + this.speed * 0.6) * factorVelocidad;
        if (this.x < limiteIzq) this.x = limiteIzq;
    }

    /**
     * Desplaza al jugador hacia la derecha en la cancha, respetando el ancho del avatar y el límite derecho.
     * 
     * @param limiteDer Coordenada máxima permitida en el eje X (borde derecho).
     */
    public void moverDerecha(double limiteDer) {
        if (aturdido || isInconsciente()) return;
        double factorVelocidad = isElectrocutado() ? 0.5 : 1.0;
        this.x += (5.0 + this.speed * 0.6) * factorVelocidad;
        if (this.x > limiteDer - this.ancho) this.x = limiteDer - this.ancho;
    }

    /**
     * Ejecuta la acción de salto del jugador si este se encuentra apoyado en el suelo.
     */
    public void saltar() {
        if (aturdido || isInconsciente() || isElectrocutado()) return;
        if (enSuelo) {
            this.velocidadY = -(10.0 + this.jump * 0.5);
            this.enSuelo = false;
        }
    }

    /**
     * Actualiza las físicas de movimiento del jugador y gestiona la recarga 
     * gradual de la barra de poder (se llena de 0 a 100 en 10 segundos).
     * 
     * @param sueloY Coordenada Y que representa la altura del suelo de la cancha.
     */
    public void actualizarFisica(double sueloY) {
        if (!enSuelo) {
            this.velocidadY += 0.5;
            this.y += this.velocidadY;

            if (this.y >= sueloY - this.alto) {
                this.y = sueloY - this.alto;
                this.velocidadY = 0;
                this.enSuelo = true;
            }
        }

        // Recarga gradual de la barra de poder: 100 unidades en 10 segundos (10 unidades por segundo).
        // Multiplicado por el tiempo transcurrido por fotograma (~0.016 segundos).
        if (this.barraPoder < 100.0) {
            this.barraPoder += 10.0 * (16.0 / 1000.0);
            if (this.barraPoder > 100.0) {
                this.barraPoder = 100.0;
            }
        }

        if (this.aturdido) {
            this.tiempoAturdidoRestante -= (16.0 / 1000.0);
            if (this.tiempoAturdidoRestante <= 0.0) {
                this.tiempoAturdidoRestante = 0.0;
                this.aturdido = false;
                this.vidaActual = getVidaMaxima(); // Vida reiniciada a vidaMax al terminar los 3s
            }
        }

        if (!enSuelo) {
            this.velocidadY += 0.5;
            this.y += this.velocidadY;

            if (this.y >= sueloY - this.alto) {
                this.y = sueloY - this.alto;
                this.velocidadY = 0;
                this.enSuelo = true;
            }
        }

        if (this.barraPoder < 100.0) {
            this.barraPoder += 10.0 * (16.0 / 1000.0);
            if (this.barraPoder > 100.0) {
                this.barraPoder = 100.0;
            }
        }

        if (this.tiempoEfectoRestante > 0.0) {
            this.tiempoEfectoRestante -= (16.0 / 1000.0);
            if (this.tiempoEfectoRestante <= 0.0) {
                this.tiempoEfectoRestante = 0.0;
                this.efectoRecibido = "Ninguno";
            }
        }
    }

    /**
     * Consume la barra de poder por completo (la reinicia a 0) al activar una habilidad,
     * iniciando de inmediato su ciclo de recarga de 10 segundos.
     * 
     * @return True si el poder estaba cargado y se pudo usar, false en caso contrario.
     */
    public boolean usarPoder() {
        if (this.barraPoder >= 100.0 && !this.tienePoderActivo) {
            this.barraPoder = 0.0;
            this.tienePoderActivo = true;
            this.poderActivo = obtenerNombrePoderPorPais();
            return true;
        }
        return false;
    }
   

    /**
     * Aplica daño al jugador. La vida nunca baja de 0.0.
     * Si llega a 0.0, el jugador queda aturdido durante 3 segundos.
     *
     * @param danio Cantidad de daño a aplicar.
     */
    public void recibirDanio(double danio) {
        if (danio <= 0.0) return;
        this.vidaActual = Math.max(0.0, this.vidaActual - danio);
        if (this.vidaActual <= 0.0 && !this.aturdido) {
            this.aturdido = true;
            this.tiempoAturdidoRestante = 3.0; // 3 segundos de aturdimiento según especificación
        }
    }

    /**
     * Reinicia la vida al máximo y limpia el estado de aturdimiento.
     */
    public void restaurarVidaCompleta() {
        this.vidaActual = getVidaMaxima();
        this.aturdido = false;
        this.tiempoAturdidoRestante = 0.0;
    }

    public boolean isAturdido() {
        return aturdido;
    }

    public double getTiempoAturdidoRestante() {
        return tiempoAturdidoRestante;
    }

    // Getters y Setters actualizados para cumplir con toda la información requerida
    /** @return País del jugador. */
    public String getPais() { return pais; }
    
    /** @return Posición X actual. */
    public double getX() { return x; }
    
    /** @return Posición Y actual. */
    public double getY() { return y; }
    
    /** @return Ancho del avatar. */
    public double getAncho() { return ancho; }
    
    /** @return Alto del avatar. */
    public double getAlto() { return alto; }
    
    /** @return Vida actual del jugador. */
    public double getVidaActual() { return vidaActual; }
    
    /** @param vidaActual Nuevo valor de vida actual. */
    public void setVidaActual(double vidaActual) { this.vidaActual = vidaActual; }
    
    /** @return Cantidad de goles anotados. */
    public int getGoles() { return goles; }
    
    /** Incrementa en uno el marcador de goles del jugador. */
    public void sumarGol() { this.goles++; }

    /** @return Nivel de la barra de poder. */
    public double getBarraPoder() { return barraPoder; }
    
    /** @param barraPoder Nuevo valor para la barra de poder. */
    public void setBarraPoder(double barraPoder) { this.barraPoder = barraPoder; }

    /** @return True si tiene poder activo, false en caso contrario. */
    public boolean isTienePoderActivo() { return tienePoderActivo; }
    
    /** @param tienePoderActivo Estado del poder activo. */
    public void setTienePoderActivo(boolean tienePoderActivo) { this.tienePoderActivo = tienePoderActivo; }

    /** @return Nombre del poder activo. */
    public String getPoderActivo() { return poderActivo; }
    
    /** @param poderActivo Nombre del nuevo poder activo. */
    public void setPoderActivo(String poderActivo) { this.poderActivo = poderActivo; }

    /** @return Valor de velocidad (speed). */
    public int getSpeed() { return speed; }
    
    /** @return Valor de salto (jump). */
    public int getJump() { return jump; }
    
    /** @return Valor de patada (kick). */
    public int getKick() { return kick; }
    
    /** @return Valor de supervivencia (survival). */
    public int getSurvival() { return survival; }

    /** @return Puntos acumulados. */
    public int getPuntos() { return puntos; }
    
    /** @param puntos Cantidad de puntos a sumar. */
    public void sumarPuntos(int puntos) { this.puntos += puntos; }
    
    /** @param puntos Nuevo valor absoluto de puntos. */
    public void setPuntos(int puntos) { this.puntos = puntos; }

    /**
     * Activa el efecto visual temporal del círculo de patada.
     */
    public void activarPatadaVisual() {
        this.framesEfectoPatada = 10; // Duración del destello en fotogramas
    }

    /**
     * Reduce fotograma a fotograma el contador del efecto visual de la patada.
     */
    public void actualizarEfectoPatada() {
        if (this.framesEfectoPatada > 0) {
            this.framesEfectoPatada--;
        }
    }

    /**
     * Obtiene los fotogramas restantes del efecto visual de patada.
     * 
     * @return Cantidad de fotogramas restantes.
     */
    public int getFramesEfectoPatada() {
        return framesEfectoPatada;
    }
    

    /** Consume el aura del poder cuando el jugador toca el balón para ejecutar el tiro. */
    public void consumirPoderAlTocarBalon() {
        this.tienePoderActivo = false;
        this.poderActivo = "Ninguno";
    }

    public String obtenerNombrePoderPorPais() {
        if ("Corea del Sur".equalsIgnoreCase(pais) || "Corea".equalsIgnoreCase(pais)) return "Aura Azul";
        if ("Camerún".equalsIgnoreCase(pais)) return "Rayo";
        if ("Nigeria".equalsIgnoreCase(pais)) return "Tornado";
        if ("Estados Unidos".equalsIgnoreCase(pais)) return "Ilusión";
        return "Aura Azul";
    }

    /** Daño base escalado (DañoTiro x 5) según el Anexo 1. */
    public double obtenerDanioBasePoder() {
        if ("Corea del Sur".equalsIgnoreCase(pais) || "Corea".equalsIgnoreCase(pais)) return 40.0;
        if ("Camerún".equalsIgnoreCase(pais)) return 60.0;
        if ("Nigeria".equalsIgnoreCase(pais)) return 40.0;
        if ("Estados Unidos".equalsIgnoreCase(pais)) return 30.0;
        return 40.0;
    }

    /** Duración del efecto del tiro de poder en segundos según el Anexo 1. */
    public double obtenerDuracionEfectoPoder() {
        if ("Corea del Sur".equalsIgnoreCase(pais) || "Corea".equalsIgnoreCase(pais)) return 1.5;
        if ("Camerún".equalsIgnoreCase(pais)) return 3.0;
        if ("Nigeria".equalsIgnoreCase(pais)) return 3.0;
        if ("Estados Unidos".equalsIgnoreCase(pais)) return 2.5;
        return 2.0;
    }

    /** Nombre del efecto que produce el tiro de poder de este país al golpear al rival. */
    public String obtenerEfectoPoderPorPais() {
        if ("Corea del Sur".equalsIgnoreCase(pais) || "Corea".equalsIgnoreCase(pais)) return "Empuje";
        if ("Camerún".equalsIgnoreCase(pais)) return "Electrocutado";
        if ("Nigeria".equalsIgnoreCase(pais)) return "Inconsciente";
        if ("Estados Unidos".equalsIgnoreCase(pais)) return "Confusión";
        return "Ninguno";
    }

    /**
     * Aplica el efecto de un tiro de poder rival, reemplazando cualquier efecto activo previo.
     */
    public void aplicarEfectoPoder(String efecto, double duracionSegundos, boolean esJugador1) {
        this.efectoRecibido = efecto;
        this.tiempoEfectoRestante = duracionSegundos;

        if ("Empuje".equalsIgnoreCase(efecto)) {
            double empujeX = esJugador1 ? -45.0 : 45.0;
            this.x += empujeX;
            this.velocidadY = -5.0;
            this.enSuelo = false;
        } else if ("Inconsciente".equalsIgnoreCase(efecto)) {
            this.velocidadY = -12.0;
            this.enSuelo = false;
        }
    }

    public boolean isInconsciente() {
        return "Inconsciente".equalsIgnoreCase(efectoRecibido) && tiempoEfectoRestante > 0.0;
    }

    public boolean isElectrocutado() {
        return "Electrocutado".equalsIgnoreCase(efectoRecibido) && tiempoEfectoRestante > 0.0;
    }

    public boolean isConfundido() {
        return "Confusión".equalsIgnoreCase(efectoRecibido) && tiempoEfectoRestante > 0.0;
    }

    public String getEfectoRecibido() { return efectoRecibido; }
    public double getTiempoEfectoRestante() { return tiempoEfectoRestante; }
}